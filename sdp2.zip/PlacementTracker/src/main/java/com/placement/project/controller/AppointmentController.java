package com.placement.project.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.placement.project.model.Appointment;
import com.placement.project.service.AppointmentService;

@Controller
@RequestMapping("/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping("/{id}")
    public ModelAndView viewAppointment(@PathVariable("id") Long id) {
        Appointment appointment = appointmentService.getAppointmentById(id);
        if (appointment == null) {
            return new ModelAndView("error", "message", "Appointment not found");
        }
        ModelAndView mav = new ModelAndView("view-appointment");
        mav.addObject("appointment", appointment);
        return mav;
    }
    
    
    @GetMapping("/view-appointment.jsp")
    public String viewAppointmentsPage() {
        return "view-appointment";
    }

    @GetMapping("/create_appointment.jsp")
    public String createAppointmentPage() {
        return "create_appointment";
    }

}
