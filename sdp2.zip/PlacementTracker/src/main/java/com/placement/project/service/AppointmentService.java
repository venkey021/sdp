package com.placement.project.service;

import com.placement.project.model.Appointment;
import java.util.List;
public interface AppointmentService {
    Appointment getAppointmentById(Long id);
    // Other service methods...
}
